/* http://api.weatherapi.com/v1

JSON: http://api.weatherapi.com/v1/search.json?key=6234c0fd79794bf190d131213231402&q=lond

http://api.weatherapi.com/v1/forecast.json?key=6234c0fd79794bf190d131213231402&q=Cairo&days=3&aqi=no&alerts=no
 */
/*http://api.weatherapi.com/v1/forecast.json?key=6234c0fd79794bf190d131213231402&q=Cairo&days=3*/




async function getData() {

    let location = document.getElementById('location');
    let currentTemp = document.getElementById('temp');
    let currentIcon = document.getElementById('icon-img');
    let currentConditionText = document.getElementById('temp-status');
    let currentDay = document.getElementById('day');
    let currentDayMonth = document.getElementById('dayMonth');

    let data = await fetch('http://api.weatherapi.com/v1/forecast.json?key=6234c0fd79794bf190d131213231402&days=3&q=Cairo');
    let result = await data.json();

    //console.log(result);


    //  console.log(new Date(result.current.last_updated));

    let dateObject = new Date(result.current.last_updated);
    console.log(dateObject);
    let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    let month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    //console.log(dateObject.getDate());
    //console.log(days[dateObject.getDay()]);
    //console.log(month[dateObject.getMonth()]);

    let getDate = dateObject.getDate(); // day number in month
    let getDay = days[dateObject.getDay()]; // day name
    let getMonth = month[dateObject.getMonth()]; // month name

    //console.log(getDate);
    // console.log(getDay);
    // console.log(getMonth);

    // get day name
    currentDay.innerHTML = getDay;
    //get day number in month concat month name
    currentDayMonth.innerHTML = getDate + " " + getMonth;

    location.innerHTML = result.location.name;
    currentTemp.innerHTML = `<div class="temp">${result.current.temp_c}<sup>o</sup>C</div>`;
    currentIcon.innerHTML = `<img width="120" height="120"src="${result.current.condition.icon}">`;
    currentConditionText.innerHTML = result.current.condition.text;
}
//getData();

var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
let currentLocation = document.getElementById('location');
let currentTemp = document.getElementById('temp');
let currentIcon = document.getElementById('icon-img');
let currentConditionText = document.getElementById('temp-status');
let currentDay = document.getElementById('day');
let currentDayMonth = document.getElementById('dayMonth');
var searchInput = document.getElementById('search');
var searchBtn = document.getElementById('submit');



async function startedData(keyword) {

    let data = await fetch('http://api.weatherapi.com/v1/forecast.json?key=6234c0fd79794bf190d131213231402&days=3&q=' + keyword);
    // console.log(data);

    if (data.status == 200 && data.ok == true) {
        let result = await data.json();
        viewToday(result.location, result.current);
        viewOtherDayes(result.forecast.forecastday);
        console.log(result);
    }
    // arr = result;
    //console.log(arr);
}

// show current day and location
function viewToday(location, current) {
    if (current != null && location != null) {
        // make conustractor for date to get new object form date
        let dateObject = new Date(current.last_updated);
        let getDate = dateObject.getDate(); // day number in month
        let getDay = days[dateObject.getDay()]; // day name
        let getMonth = month[dateObject.getMonth()]; // month name

        // get day name
        // currentDay.innerHTML = getDay;
        //get day number in month concat month name
        // currentDayMonth.innerHTML = getDate + " " + getMonth;

        // currentLocation.innerHTML = location.name;
        // currentTemp.innerHTML = `<div class="temp">${current.temp_c}<sup>o</sup>C</div>`;
        // currentIcon.innerHTML = `<img width="120" height="120"src="${current.condition.icon}">`;
        // currentConditionText.innerHTML = current.condition.text;

        currentContainer = `
        <div class="col-md-4 m-0 p-0">
                            <div class="card today fisrt_and_last">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div id="day">${getDay}</div>
                                    <div id="dayMonth">${getDate + " " + getMonth}</div>
                                </div>
                                <div class="card-body">
                                    <div class="card-title location" id="location">${location.name}</div>
                                    <div class="temp-info d-flex justify-content-between align-items-center">
                                        <div id="temp" class="temp">${current.temp_c}<sup>o</sup>C</div>
                                        <div class="icon-img" id="icon-img">
                                        <img width="120" height="120"src="${current.condition.icon}">
                                        </div>
                                        
                                    </div>
                                    <div class="temp-status" id="temp-status">${current.condition.text}</div>
                                    <span><img src="img/icon-umberella.png" alt="">20%</span>
                                    <span><img src="img/icon-wind.png" alt="">18km/h</span>
                                    <span><img src="img/icon-compass.png" alt="">East</span>
                                </div>
                            </div>
                        </div>
        `;
        document.getElementById('div_container').innerHTML = currentContainer;
    }

}


// show current day and location
function viewOtherDayes(forecast) {
    // make conustractor for date to get new object form date
    // let dateObject = new Date(forecast[1].date);
    //let d = days[new Date(forecast[1].date).getDay()]
    // console.log(days[dateObject.getDay()]);
    //console.log(days[new Date(forecast[1].date).getDay()]);

    let Conatiner = '';
    for (let i = 1; i < forecast.length; i++) {

        Conatiner += `
        <div class="col-md-4 m-0 p-0 other_day">
            <div class="card ">
                <div class="card-header d-flex justify-content-center">
                    <div>${days[new Date(forecast[i].date).getDay()]}</div>
                </div>
                <div class="card-body">
                    <div class="public-icon">
                        <img src="${forecast[i].day.condition.icon}" alt="">
                    </div>
                    <div class="up-temp mb-2">${forecast[i].day.maxtemp_c}<sup>0</sup>C</div>
                    <div class="small-temp">${forecast[i].day.mintemp_c}<sup>0</sup></div>
                    <div class="temp-status">${forecast[i].day.condition.text}</div>
                </div>
            </div>
        </div>
        `;

    }
    document.getElementById('div_container').innerHTML += Conatiner;
}


searchBtn.addEventListener("click", function () {
    if (searchInput.value.toLowerCase() != null && searchInput.value.toLowerCase() != '') {
        startedData(searchInput.value.toLowerCase());
    }
    startedData('Cairo');
});

searchInput.addEventListener("keyup", function () {
    console.log(searchInput.value);
    if (searchInput.value != null && searchInput.value != '') {
        startedData(searchInput.value.toLowerCase());
    }
    startedData('Cairo');
});

startedData('Cairo');
